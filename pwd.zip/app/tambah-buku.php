<?php
	include './config/koneksi-db.php';

	if(!isset($_POST['simpan'])) {
		/* Mempersiapkan ID Anggota Baru */
		$sql = "SELECT id_buku FROM buku;";
		$query = mysqli_query($db_conn, $sql);
		$row = $query->num_rows;

		$id_buku_tmp;
		$id_kategori_tmp;
		$id_penulis_tmp;
		$id_penerbit_tmp;
?>

		<div id="container">
			<div class="page-title">
				<h3>Tambah Data Buku</h3>	
			</div>
			<div class="page-content">
				<form action="" method="post" enctype="multipart/form-data">
					<table class="form-table">
						<tr>
							<td>
								<label for="id_buku">ID Buku</label>
							</td>
							<td>					
								<input type="text" name="id_buku" id="id_buku" required>
							</td>
						</tr>
						<tr>
							<td>
								<label for="judul_buku">Judul Buku</label>
							</td>
							<td>								
								<input type="text" name="judul_buku" id="judul_buku" required>
							</td>
						</tr>
						<tr>
							<td>
								<label for="id_kategori">ID Kategori</label>
							</td>
							<td>					
								<input type="text" name="id_kategori" id="id_kategori" required>
							</td>
						</tr>
						<tr>
							<td>
								<label for="id_penulis">ID Penulis</label>
							</td>
							<td>					
								<input type="text" name="id_penulis" id="id_penulis" required>
							</td>
						</tr>
						<tr>
							<td>
								<label for="id_penerbit">ID Penerbit</label>
							</td>
							<td>					
								<input type="text" name="id_penerbit" id="id_penerbit" required>
							</td>
						</tr>
						<tr>
							<td>
								<label>Status</label>
							</td>
							<td>								
								<input type="radio" name="status" value="T" id="tersedia" required>

								<label for="tersedia">Tersedia</label>

								<input type="radio" name="status" value="D" id="dipinjam" required>
								<label for="dipinjam">Dipinjam</label>
							</td>
						</tr>
						<tr>
							<td>
								&nbsp;
							</td>
							<td>								
								<input type="submit" name="simpan" value="Simpan">
							</td>
						</tr>						
					</table>
				</form>
			</div>
		</div>

<?php 
	} else { 
		/* Proses Penyimpanan Data dari Form */

		$id_buku 	    = $_POST['id_buku'];
		$judul_buku 	= $_POST['judul_buku'];
		$id_kategori	= $_POST['id_kategori'];
		$id_penulis		= $_POST['id_penulis'];
		$id_penerbit	= $_FILES['id_penerbit'];
		$status     	= $_FILES['status'];

	

		// Query
		$sql = "INSERT INTO buku
				VALUES('{$id_buku}', '{$judul_buku}', '{$id_kategori}', 
						'{$id_penulis}', '{$id_penerbit}', '{$status}')";
		$query = mysqli_query($db_conn, $sql);

		// mengalihkan halaman
		echo "<meta http-equiv='refresh' content='0; url=index.php?p=buku'>";
	}
?>