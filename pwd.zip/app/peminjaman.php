<?php
    include './config/koneksi-db.php';

    $row = 0;
    $num = 0;
    $offset = 0;
    if(!isset($_POST['cari'])) { 
        if(isset($_GET['num'])) { 
            $num = (int)$_GET['num'];

            if($num > 0) {
                $offset = ($num * $_QUERY_LIMIT) - $_QUERY_LIMIT;
            }
        }

        $sql = "SELECT id_transaksi, nama_lengkap, judul_buku, tanggal_pinjam FROM anggota, buku, transaksi ORDER BY id_transaksi DESC LIMIT {$offset}, {$_QUERY_LIMIT};";
        $query = mysqli_query($db_conn, $sql);

        $sql_count = "SELECT id_transaksi FROM transaksi;";
        $query_count = mysqli_query($db_conn, $sql_count);      
        $row = $query_count->num_rows;
    } else {
        $kata_kunci = $_POST['kata_kunci'];

        if(!empty($kata_kunci)) {
            
            $sql = "SELECT id_transaksi, nama_lengkap, judul_buku, tanggal_pinjam FROM anggota, buku, transaksi
                    WHERE id_transaksi LIKE '%{$kata_kunci}%'
                        OR nama_lengkap LIKE '%{$kata_kunci}%'
                        OR judul_buku LIKE '%{$kata_kunci}%'
                        OR tanggal_pinjam LIKE '%{$kata_kunci}%'
                    ORDER BY id_transaksi DESC;";
            $query = mysqli_query($db_conn, $sql);
            $row = $query->num_rows;
        }
    }
?>

        <div id="container">
            <div class="page-title">
                <h3>Transaksi Peminjaman</h3>   
            </div>
            <div class="page-content">
                <div class="table-upper">
                    <div class="table-upper-right">
                        <form name="pencarian_anggota" action="" method="post" class="mg-top-15 text-right">
                            <input type="text" name="kata_kunci">
                            <input type="submit" name="cari" value="Cari">
                        </form>
                    </div>
                </div>

            <?php 
                if($row > 0) {
            ?>
                <table class="data-table">
                    <tr>
                        <th>No.</th>
                        <th>ID Transaksi</th>
                        <th>Nama Anggota</th>
                        <th>Judul Buku</th>
                        <th>Tanggal Pinjam</th>
                    </tr>
                <?php
                    $i = 1;
                    while($data = mysqli_fetch_array($query)) {
                ?>
                    <tr>
                        <td class="text-center"><?php echo $i++; ?></td>
                        <td><?php echo $data['id_transaksi']; ?></td>
                        <td><?php echo $data['nama_lengkap']; ?></td>
                        <td><?php echo $data['judul_buku']; ?></td>
                        <td><?php echo $data['tanggal_pinjam']; ?></td>
                    </tr>
                <?php
                    }
                ?>
                </table>
                
            <?php } else { ?>
                <p class="text-center">Data tidak tersedia.</p>
            <?php } ?>      
            </div>
        </div>