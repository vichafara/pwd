		<div id="container">
			<div class="page-title">
				<h3>Error 404</h3>	
			</div>
			<div class="page-content text-center">
				<h4>Halaman Tidak Ditemukan!</h4>
			</div>
				<p class="quote">&quot;Ups! Halaman yang Anda cari tidak ditemukan. Silahkan gunakan menu navigasi disamping kiri.&quot;</p>
		</div>