		<div id="container">
			<div class="page-title">
				<h3>Beranda</h3>	
			</div>
			<div class="page-content text-center">
				<h4>Selamat Datang di Sistem Informasi Perpustakaan!</h4>
				<p class="quote">&quot;Membaca adalah Jendela Dunia&quot;</p>
				<img src="assets/img/buku.jpg" width="30%">
			</div>
		</div>