<?php

	$_SITE_TITLE		= '';
	$_SITE_DESC_ADDRESS	= '';
	$_SITE_DESC_PHONE	= '';
	$_SITE_INFO			= 'Kereta Api Yogyakarta';
	$_SITE_CREDIT		= 'Copyright Literate Hub Yogyakarta 2023';
	$_PATH_APP			= './app';
	$_PATH_IMAGE		= './images';
	$_QUERY_LIMIT		= 5;

?>